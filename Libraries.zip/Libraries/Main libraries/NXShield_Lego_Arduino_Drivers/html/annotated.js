var annotated =
[
    [ "ClassDIMUAccel", "class_class_d_i_m_u_accel.html", "class_class_d_i_m_u_accel" ],
    [ "ClassDIMUGyro", "class_class_d_i_m_u_gyro.html", "class_class_d_i_m_u_gyro" ],
    [ "ClassHTAC", "class_class_h_t_a_c.html", "class_class_h_t_a_c" ],
    [ "ClassHTCS", "class_class_h_t_c_s.html", "class_class_h_t_c_s" ],
    [ "ClassHTGYRO", "class_class_h_t_g_y_r_o.html", "class_class_h_t_g_y_r_o" ],
    [ "ClassHTIRR", "class_class_h_t_i_r_r.html", "class_class_h_t_i_r_r" ],
    [ "ClassHTIRS", "class_class_h_t_i_r_s.html", "class_class_h_t_i_r_s" ],
    [ "ClassHTMC", "class_class_h_t_m_c.html", "class_class_h_t_m_c" ],
    [ "ClassNXTSound", "class_class_n_x_t_sound.html", "class_class_n_x_t_sound" ]
];