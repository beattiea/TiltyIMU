var _h_t_i_r_r__driver_8h =
[
    [ "HTIRR_CHANNEL_1", "_h_t_i_r_r__driver_8h.html#a0b1247ead6c0d86a089f65a24c6fbacc", null ],
    [ "HTIRR_CHANNEL_2", "_h_t_i_r_r__driver_8h.html#abba07f7d0fb9b8b994291bf7f2cbd22d", null ],
    [ "HTIRR_CHANNEL_3", "_h_t_i_r_r__driver_8h.html#aca5baa7b1f67fd009c23607af6f8c952", null ],
    [ "HTIRR_CHANNEL_4", "_h_t_i_r_r__driver_8h.html#a8e91b9b9ed27a1e7f28e6900cc79b3e6", null ],
    [ "HTIRR_I2C_ADDR", "_h_t_i_r_r__driver_8h.html#ada8e811dde4008cc18f990f08aebb2f2", null ],
    [ "HTIRR_MOTOR_1A", "_h_t_i_r_r__driver_8h.html#a1706689430db530975a3ecc2b804b626", null ],
    [ "HTIRR_MOTOR_1B", "_h_t_i_r_r__driver_8h.html#a2166ed8ed23a1069a9e6db6c8012343a", null ],
    [ "HTIRR_MOTOR_2A", "_h_t_i_r_r__driver_8h.html#afd018add38caacbcd83e70c64f34261b", null ],
    [ "HTIRR_MOTOR_2B", "_h_t_i_r_r__driver_8h.html#a7c687a7897ac8b6b729c01856bdafa1b", null ],
    [ "HTIRR_MOTOR_3A", "_h_t_i_r_r__driver_8h.html#a9b4d3eb0827e39fcf914b962b7ca4cc2", null ],
    [ "HTIRR_MOTOR_3B", "_h_t_i_r_r__driver_8h.html#a0667b166a679937c14d89a2a0547edbb", null ],
    [ "HTIRR_MOTOR_4A", "_h_t_i_r_r__driver_8h.html#a16d9779a94de5060e6e4ba8a1c1ee5a3", null ],
    [ "HTIRR_MOTOR_4B", "_h_t_i_r_r__driver_8h.html#a6c30799c1377c00b5d7770ff055e8bc6", null ]
];