var _h_t_a_c__driver_8h =
[
    [ "AXIS_X", "_h_t_a_c__driver_8h.html#a753faa457a1c2937ea3fdcdb83c3ca5f", null ],
    [ "AXIS_Y", "_h_t_a_c__driver_8h.html#a08f3e26d90cf66bf2840d476e5d4711f", null ],
    [ "AXIS_Z", "_h_t_a_c__driver_8h.html#a220ebc22eb87c8989bfd63ae3cbbe2a8", null ],
    [ "HTAC_I2C_ADDR", "_h_t_a_c__driver_8h.html#a7912e28221d7e2a639d90fd332f39a11", null ]
];