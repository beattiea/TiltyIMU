var _n_x_t_sound__driver_8h =
[
    [ "NXT_SOUND_TYPE_DB", "_n_x_t_sound__driver_8h.html#a7e1437d358aafdeea6e9a7f35f88947e", null ],
    [ "NXT_SOUND_TYPE_DBA", "_n_x_t_sound__driver_8h.html#a6d7e2d31060134be7622265f0ee5fe36", null ]
];