var searchData=
[
  ['serialfloatprint',['serialFloatPrint',['../CommunicationUtils_8cpp.html#a443fb70b5dfe2023992cec53792aa77e',1,'serialFloatPrint(float f):&#160;CommunicationUtils.cpp'],['../CommunicationUtils_8h.html#a443fb70b5dfe2023992cec53792aa77e',1,'serialFloatPrint(float f):&#160;CommunicationUtils.cpp']]],
  ['serialprintfloatarr',['serialPrintFloatArr',['../CommunicationUtils_8cpp.html#ac255bc45ca336cd7cc89d2b85463c5d0',1,'serialPrintFloatArr(float *arr, int length):&#160;CommunicationUtils.cpp'],['../CommunicationUtils_8h.html#ac255bc45ca336cd7cc89d2b85463c5d0',1,'serialPrintFloatArr(float *arr, int length):&#160;CommunicationUtils.cpp']]]
];
